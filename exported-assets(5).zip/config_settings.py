# config/settings.py
"""
Projekt Feniks - Konfiguracja systemu
Centralny system konfiguracji dla wszystkich modułów
"""

import os
from dataclasses import dataclass
from typing import List, Dict, Any

@dataclass
class RedisConfig:
    host: str = os.getenv('REDIS_HOST', 'localhost')
    port: int = int(os.getenv('REDIS_PORT', '6379'))
    db: int = int(os.getenv('REDIS_DB', '0'))
    password: str = os.getenv('REDIS_PASSWORD', '')
    max_connections: int = 100

@dataclass
class RabbitMQConfig:
    host: str = os.getenv('RABBITMQ_HOST', 'localhost')
    port: int = int(os.getenv('RABBITMQ_PORT', '5672'))
    username: str = os.getenv('RABBITMQ_USER', 'guest')
    password: str = os.getenv('RABBITMQ_PASS', 'guest')
    virtual_host: str = os.getenv('RABBITMQ_VHOST', '/')

@dataclass
class PostgreSQLConfig:
    host: str = os.getenv('POSTGRES_HOST', 'localhost')
    port: int = int(os.getenv('POSTGRES_PORT', '5432'))
    database: str = os.getenv('POSTGRES_DB', 'feniks')
    username: str = os.getenv('POSTGRES_USER', 'feniks')
    password: str = os.getenv('POSTGRES_PASSWORD', 'feniks')

@dataclass
class PrometheusConfig:
    port: int = int(os.getenv('PROMETHEUS_PORT', '8000'))
    push_gateway: str = os.getenv('PROMETHEUS_PUSH_GATEWAY', 'localhost:9091')

@dataclass
class SystemConfig:
    redis: RedisConfig = RedisConfig()
    rabbitmq: RabbitMQConfig = RabbitMQConfig()
    postgresql: PostgreSQLConfig = PostgreSQLConfig()
    prometheus: PrometheusConfig = PrometheusConfig()

    # Worker Configuration
    max_workers: int = int(os.getenv('MAX_WORKERS', '10'))
    worker_timeout: int = int(os.getenv('WORKER_TIMEOUT', '300'))

    # Circuit Breaker Configuration
    circuit_breaker_threshold: int = int(os.getenv('CB_THRESHOLD', '5'))
    circuit_breaker_timeout: int = int(os.getenv('CB_TIMEOUT', '30'))

    # Selenium Configuration
    selenium_timeout: int = int(os.getenv('SELENIUM_TIMEOUT', '45'))
    selenium_headless: bool = os.getenv('SELENIUM_HEADLESS', 'True').lower() == 'true'

    # Logging Configuration
    log_level: str = os.getenv('LOG_LEVEL', 'INFO')
    log_format: str = os.getenv('LOG_FORMAT', 'json')

# Singleton instance
config = SystemConfig()
