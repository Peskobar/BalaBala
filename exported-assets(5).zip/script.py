# Tworzenie diagramu architektury systemu Projekt Feniks
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch, Rectangle
import numpy as np

fig, ax = plt.subplots(1, 1, figsize=(16, 12))

# Kolory zgodne z motywem enterprise
colors = {
    'scout': '#2E7D32',     # Zielony
    'operator': '#1976D2',   # Niebieski
    'analyst': '#7B1FA2',   # Fioletowy
    'infra': '#F57C00',     # Pomarańczowy
    'api': '#C62828'        # Czerwony
}

# Funkcja do rysowania komponentów
def draw_component(x, y, width, height, text, color, text_size=10):
    box = FancyBboxPatch((x, y), width, height,
                        boxstyle="round,pad=0.02",
                        facecolor=color,
                        edgecolor='black',
                        alpha=0.8)
    ax.add_patch(box)
    ax.text(x + width/2, y + height/2, text,
           ha='center', va='center',
           fontsize=text_size, fontweight='bold',
           color='white', wrap=True)

# Moduł Scout (górny lewy)
draw_component(1, 8, 3, 1.5, 'ProxyHarvester\n(Zbieranie Proxy)', colors['scout'])
draw_component(1, 6, 3, 1.5, 'ProxyValidator\n(Walidacja Proxy)', colors['scout'])
draw_component(1, 4, 3, 1.5, 'SMSHarvester\n(Zbieranie SMS)', colors['scout'])
draw_component(1, 2, 3, 1.5, 'SMSValidator\n(Walidacja SMS)', colors['scout'])

# Moduł Operator (środek)
draw_component(6, 7, 3, 1.5, 'AttemptScheduler\n(Planowanie)', colors['operator'])
draw_component(6, 5, 3, 1.5, 'RegistrationAgent\n(Wykonywanie)', colors['operator'])
draw_component(6, 3, 3, 1.5, 'ResourceManager\n(Zasoby)', colors['operator'])

# Moduł Analyst (górny prawy)
draw_component(11, 8, 3, 1.5, 'FailureClassifier\n(Klasyfikacja)', colors['analyst'])
draw_component(11, 6, 3, 1.5, 'ScoringEngine\n(Ocenianie)', colors['analyst'])
draw_component(11, 4, 3, 1.5, 'StrategyAdjuster\n(Strategia)', colors['analyst'])
draw_component(11, 2, 3, 1.5, 'MLPredictor\n(Predykcja)', colors['analyst'])

# Infrastruktura (dolny pasek)
draw_component(2, 0.2, 2.5, 1, 'Redis\n(Cache)', colors['infra'])
draw_component(5, 0.2, 2.5, 1, 'RabbitMQ\n(Kolejki)', colors['infra'])
draw_component(8, 0.2, 2.5, 1, 'PostgreSQL\n(Dane)', colors['infra'])
draw_component(11, 0.2, 2.5, 1, 'Prometheus\n(Monitoring)', colors['infra'])

# API Gateway (prawy brzeg)
draw_component(15, 3, 1.5, 4, 'API\nGateway\n\nREST\nEndpoints', colors['api'], 9)

# Strzałki połączeń
def draw_arrow(x1, y1, x2, y2, color='black', width=2):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle='->', color=color, lw=width))

# Połączenia Scout -> Infrastructure
draw_arrow(4.5, 5, 5, 1.2, colors['scout'])
draw_arrow(4.5, 3, 5, 1.2, colors['scout'])

# Połączenia Operator -> Infrastructure
draw_arrow(6, 6, 5.5, 1.2, colors['operator'])
draw_arrow(6, 4, 6.5, 1.2, colors['operator'])

# Połączenia Analyst -> Infrastructure
draw_arrow(11, 5, 10, 1.2, colors['analyst'])
draw_arrow(11, 3, 10, 1.2, colors['analyst'])

# Połączenia do API Gateway
draw_arrow(14.5, 5, 15, 5, colors['api'])

# Tytuły modułów
ax.text(2.5, 10, 'SCOUT MODULE', ha='center', fontsize=14, fontweight='bold', color=colors['scout'])
ax.text(7.5, 10, 'OPERATOR MODULE', ha='center', fontsize=14, fontweight='bold', color=colors['operator'])
ax.text(12.5, 10, 'ANALYST MODULE', ha='center', fontsize=14, fontweight='bold', color=colors['analyst'])

# Tytuł główny
ax.text(8.5, 11.5, 'PROJEKT FENIKS - ARCHITEKTURA WIELOAGENTOWA', 
        ha='center', fontsize=18, fontweight='bold')

# Legenda
legend_elements = [
    patches.Patch(color=colors['scout'], label='Scout Module (Zwiadowcy)'),
    patches.Patch(color=colors['operator'], label='Operator Module (Operatorzy)'),
    patches.Patch(color=colors['analyst'], label='Analyst Module (Analitycy)'),
    patches.Patch(color=colors['infra'], label='Infrastructure (Infrastruktura)'),
    patches.Patch(color=colors['api'], label='API Gateway')
]
ax.legend(handles=legend_elements, loc='upper right', bbox_to_anchor=(1, 0.15))

ax.set_xlim(0, 17)
ax.set_ylim(0, 12)
ax.set_aspect('equal')
ax.axis('off')

plt.tight_layout()
plt.savefig('projekt_feniks_architektura.png', dpi=300, bbox_inches='tight')
plt.show()