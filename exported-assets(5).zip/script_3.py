# 3. Infrastruktura systemu
infrastructure_code = '''# core/infrastructure.py
"""
Projekt Feniks - Infrastruktura systemu
Redis, RabbitMQ, PostgreSQL, Circuit Breaker
"""

import json
import time
import asyncio
import aioredis
import psycopg2
from typing import Dict, Any, Optional, List
from contextlib import asynccontextmanager
from dataclasses import dataclass, asdict
from enum import Enum
import pika
from pika.adapters.asyncio_connection import AsyncioConnection
from pycircuitbreaker import CircuitBreaker, CircuitBreakerRegistry

class TaskStatus(Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"

@dataclass
class Task:
    """Podstawowa struktura zadania"""
    id: str
    type: str
    payload: Dict[str, Any]
    status: TaskStatus = TaskStatus.PENDING
    priority: int = 5
    max_retries: int = 3
    current_retry: int = 0
    created_at: float = None
    scheduled_for: float = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = time.time()
        if self.scheduled_for is None:
            self.scheduled_for = time.time()

class RedisManager:
    """Zarządzanie połączeniem Redis z poolem połączeń"""
    
    def __init__(self, config):
        self.config = config
        self.pool = None
        self.logger = None
    
    async def initialize(self):
        """Inicjalizacja puli połączeń Redis"""
        from core.logging import StructuredLogger
        self.logger = StructuredLogger("redis_manager")
        
        try:
            self.pool = aioredis.ConnectionPool.from_url(
                f"redis://{self.config.host}:{self.config.port}/{self.config.db}",
                password=self.config.password if self.config.password else None,
                max_connections=self.config.max_connections
            )
            
            # Test połączenia
            async with aioredis.Redis(connection_pool=self.pool) as redis:
                await redis.ping()
            
            self.logger.info("Redis connection pool initialized successfully")
            
        except Exception as e:
            self.logger.error("Failed to initialize Redis connection pool", exception=e)
            raise
    
    @asynccontextmanager
    async def get_connection(self):
        """Context manager dla połączenia Redis"""
        redis = aioredis.Redis(connection_pool=self.pool)
        try:
            yield redis
        finally:
            await redis.close()
    
    async def set_with_expiry(self, key: str, value: Any, expire_seconds: int = 3600):
        """Ustawienie wartości z wygaśnięciem"""
        async with self.get_connection() as redis:
            if isinstance(value, dict):
                value = json.dumps(value)
            await redis.setex(key, expire_seconds, value)
    
    async def get_json(self, key: str) -> Optional[Dict]:
        """Pobranie wartości jako JSON"""
        async with self.get_connection() as redis:
            value = await redis.get(key)
            if value:
                return json.loads(value.decode())
            return None
    
    async def increment_score(self, key: str, field: str, increment: float = 1.0):
        """Inkrementacja score w hash"""
        async with self.get_connection() as redis:
            await redis.hincrbyfloat(key, field, increment)
    
    async def get_ranked_items(self, key: str, limit: int = 10) -> List[tuple]:
        """Pobranie rankingu elementów"""
        async with self.get_connection() as redis:
            return await redis.zrevrange(key, 0, limit-1, withscores=True)

class RabbitMQManager:
    """Zarządzanie kolejkami RabbitMQ"""
    
    def __init__(self, config):
        self.config = config
        self.connection = None
        self.channel = None
        self.logger = None
        self.queues = {
            'proxy_validation': 'proxy_validation_queue',
            'sms_validation': 'sms_validation_queue',
            'registration_attempt': 'registration_attempt_queue',
            'analysis': 'analysis_queue',
            'strategy_adjustment': 'strategy_adjustment_queue'
        }
    
    async def initialize(self):
        """Inicjalizacja połączenia RabbitMQ"""
        from core.logging import StructuredLogger
        self.logger = StructuredLogger("rabbitmq_manager")
        
        try:
            connection_params = pika.ConnectionParameters(
                host=self.config.host,
                port=self.config.port,
                virtual_host=self.config.virtual_host,
                credentials=pika.PlainCredentials(
                    self.config.username,
                    self.config.password
                )
            )
            
            self.connection = pika.BlockingConnection(connection_params)
            self.channel = self.connection.channel()
            
            # Deklaracja kolejek
            for queue_name in self.queues.values():
                self.channel.queue_declare(
                    queue=queue_name,
                    durable=True,
                    arguments={'x-max-priority': 10}
                )
            
            self.logger.info("RabbitMQ connection and queues initialized successfully")
            
        except Exception as e:
            self.logger.error("Failed to initialize RabbitMQ", exception=e)
            raise
    
    async def publish_task(self, queue_type: str, task: Task):
        """Publikowanie zadania do kolejki"""
        try:
            queue_name = self.queues.get(queue_type)
            if not queue_name:
                raise ValueError(f"Unknown queue type: {queue_type}")
            
            message = json.dumps(asdict(task), default=str)
            
            self.channel.basic_publish(
                exchange='',
                routing_key=queue_name,
                body=message,
                properties=pika.BasicProperties(
                    delivery_mode=2,  # Trwałość wiadomości
                    priority=task.priority
                )
            )
            
            self.logger.info(
                f"Task published to {queue_type}",
                task_id=task.id,
                queue=queue_name
            )
            
        except Exception as e:
            self.logger.error(
                f"Failed to publish task to {queue_type}",
                task_id=task.id,
                exception=e
            )
            raise
    
    def consume_tasks(self, queue_type: str, callback):
        """Konsumowanie zadań z kolejki"""
        queue_name = self.queues.get(queue_type)
        if not queue_name:
            raise ValueError(f"Unknown queue type: {queue_type}")
        
        self.channel.basic_qos(prefetch_count=1)
        self.channel.basic_consume(
            queue=queue_name,
            on_message_callback=callback
        )
        
        self.logger.info(f"Started consuming from {queue_type}", queue=queue_name)
        self.channel.start_consuming()

class DatabaseManager:
    """Zarządzanie bazą danych PostgreSQL"""
    
    def __init__(self, config):
        self.config = config
        self.connection_pool = None
        self.logger = None
    
    async def initialize(self):
        """Inicjalizacja puli połączeń"""
        from core.logging import StructuredLogger
        self.logger = StructuredLogger("database_manager")
        
        try:
            # W rzeczywistej implementacji użylibyśmy asyncpg
            # self.connection_pool = await asyncpg.create_pool(...)
            
            # Utworzenie tabel
            await self._create_tables()
            
            self.logger.info("Database connection pool initialized successfully")
            
        except Exception as e:
            self.logger.error("Failed to initialize database", exception=e)
            raise
    
    async def _create_tables(self):
        """Utworzenie tabel bazy danych"""
        tables_sql = '''
        CREATE TABLE IF NOT EXISTS proxy_resources (
            id SERIAL PRIMARY KEY,
            proxy_url VARCHAR(255) UNIQUE NOT NULL,
            provider VARCHAR(100),
            country VARCHAR(3),
            success_rate FLOAT DEFAULT 0.0,
            last_used TIMESTAMP,
            status VARCHAR(20) DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS sms_resources (
            id SERIAL PRIMARY KEY,
            service_url VARCHAR(255) UNIQUE NOT NULL,
            provider VARCHAR(100),
            success_rate FLOAT DEFAULT 0.0,
            last_used TIMESTAMP,
            status VARCHAR(20) DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS registration_attempts (
            id SERIAL PRIMARY KEY,
            agent_id VARCHAR(100),
            proxy_id INTEGER REFERENCES proxy_resources(id),
            sms_service_id INTEGER REFERENCES sms_resources(id),
            status VARCHAR(20),
            failure_code VARCHAR(100),
            duration_seconds FLOAT,
            created_account VARCHAR(255),
            error_details TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS system_metrics (
            id SERIAL PRIMARY KEY,
            metric_name VARCHAR(100),
            metric_value FLOAT,
            labels JSONB,
            recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        '''
        
        # W rzeczywistej implementacji wykonalibyśmy te zapytania
        self.logger.info("Database tables created/verified")

class EnhancedCircuitBreaker:
    """Zaawansowany Circuit Breaker z metrykami"""
    
    def __init__(self, name: str, failure_threshold: int = 5, timeout: int = 30):
        self.name = name
        self.circuit_breaker = CircuitBreaker(
            failure_threshold=failure_threshold,
            recovery_timeout=timeout,
            expected_exception=Exception
        )
        self.logger = None
        self.registry = CircuitBreakerRegistry()
        self.registry.add(self.circuit_breaker)
    
    def __call__(self, func):
        """Dekorator dla funkcji"""
        from core.logging import StructuredLogger
        if not self.logger:
            self.logger = StructuredLogger(f"circuit_breaker_{self.name}")
        
        def wrapper(*args, **kwargs):
            try:
                with self.circuit_breaker:
                    return func(*args, **kwargs)
            except Exception as e:
                self.logger.error(
                    f"Circuit breaker {self.name} - function failed",
                    function=func.__name__,
                    state=self.circuit_breaker.current_state,
                    exception=e
                )
                raise
        
        return wrapper
    
    @property
    def is_open(self) -> bool:
        """Sprawdza czy circuit breaker jest otwarty"""
        return self.circuit_breaker.current_state == 'open'
    
    def get_metrics(self) -> Dict[str, Any]:
        """Pobiera metryki circuit breaker"""
        return {
            'name': self.name,
            'state': self.circuit_breaker.current_state,
            'failure_count': self.circuit_breaker.failure_count,
            'last_failure_time': getattr(self.circuit_breaker, 'last_failure_time', None)
        }

class ResourcePool:
    """Pula zasobów z automatycznym load balancing"""
    
    def __init__(self, resource_type: str, redis_manager: RedisManager):
        self.resource_type = resource_type
        self.redis = redis_manager
        self.logger = None
    
    async def initialize(self):
        from core.logging import StructuredLogger
        self.logger = StructuredLogger(f"resource_pool_{self.resource_type}")
    
    async def get_best_resource(self) -> Optional[Dict[str, Any]]:
        """Pobiera najlepszy dostępny zasób na podstawie rankingu"""
        try:
            ranking_key = f"ranking:{self.resource_type}"
            top_resources = await self.redis.get_ranked_items(ranking_key, limit=10)
            
            for resource_data, score in top_resources:
                resource = json.loads(resource_data.decode())
                if resource.get('status') == 'active':
                    return resource
            
            return None
            
        except Exception as e:
            self.logger.error(f"Failed to get best {self.resource_type}", exception=e)
            return None
    
    async def update_resource_score(self, resource_id: str, success: bool):
        """Aktualizuje score zasobu na podstawie rezultatu"""
        try:
            ranking_key = f"ranking:{self.resource_type}"
            increment = 1.0 if success else -2.0
            await self.redis.increment_score(ranking_key, resource_id, increment)
            
            self.logger.debug(
                f"Updated {self.resource_type} score",
                resource_id=resource_id,
                success=success,
                increment=increment
            )
            
        except Exception as e:
            self.logger.error(
                f"Failed to update {self.resource_type} score",
                resource_id=resource_id,
                exception=e
            )

# Factory dla zarządzania wszystkimi komponentami infrastruktury
class InfrastructureManager:
    """Główny menedżer infrastruktury"""
    
    def __init__(self, config):
        self.config = config
        self.redis = RedisManager(config.redis)
        self.rabbitmq = RabbitMQManager(config.rabbitmq)
        self.database = DatabaseManager(config.postgresql)
        self.circuit_breakers = {}
        self.resource_pools = {}
        self.logger = None
    
    async def initialize(self):
        """Inicjalizacja całej infrastruktury"""
        from core.logging import StructuredLogger, init_monitoring
        self.logger = StructuredLogger("infrastructure_manager")
        
        try:
            # Inicjalizacja monitoringu
            init_monitoring(self.config.prometheus.port)
            
            # Inicjalizacja komponentów
            await self.redis.initialize()
            await self.rabbitmq.initialize()
            await self.database.initialize()
            
            # Utworzenie circuit breakers
            self._create_circuit_breakers()
            
            # Utworzenie pul zasobów
            await self._create_resource_pools()
            
            self.logger.info("Infrastructure initialized successfully")
            
        except Exception as e:
            self.logger.error("Failed to initialize infrastructure", exception=e)
            raise
    
    def _create_circuit_breakers(self):
        """Utworzenie circuit breakers dla kluczowych serwisów"""
        services = ['proxy_validation', 'sms_service', 'registration', 'analysis']
        
        for service in services:
            self.circuit_breakers[service] = EnhancedCircuitBreaker(
                name=service,
                failure_threshold=self.config.circuit_breaker_threshold,
                timeout=self.config.circuit_breaker_timeout
            )
    
    async def _create_resource_pools(self):
        """Utworzenie pul zasobów"""
        resource_types = ['proxy', 'sms_service']
        
        for resource_type in resource_types:
            pool = ResourcePool(resource_type, self.redis)
            await pool.initialize()
            self.resource_pools[resource_type] = pool
    
    def get_circuit_breaker(self, service: str) -> EnhancedCircuitBreaker:
        """Pobiera circuit breaker dla serwisu"""
        return self.circuit_breakers.get(service)
    
    def get_resource_pool(self, resource_type: str) -> ResourcePool:
        """Pobiera pulę zasobów"""
        return self.resource_pools.get(resource_type)
    
    async def health_check(self) -> Dict[str, Any]:
        """Sprawdzenie stanu zdrowia infrastruktury"""
        health_status = {}
        
        # Sprawdzenie Redis
        try:
            async with self.redis.get_connection() as redis:
                await redis.ping()
            health_status['redis'] = 'healthy'
        except Exception as e:
            health_status['redis'] = f'unhealthy: {str(e)}'
        
        # Sprawdzenie RabbitMQ
        try:
            health_status['rabbitmq'] = 'healthy' if self.rabbitmq.connection and not self.rabbitmq.connection.is_closed else 'unhealthy'
        except Exception as e:
            health_status['rabbitmq'] = f'unhealthy: {str(e)}'
        
        # Sprawdzenie Circuit Breakers
        cb_status = {}
        for name, cb in self.circuit_breakers.items():
            cb_status[name] = cb.get_metrics()
        health_status['circuit_breakers'] = cb_status
        
        return health_status
'''

# Zapisz infrastrukturę
with open('infrastructure_system.py', 'w', encoding='utf-8') as f:
    f.write(infrastructure_code)

print("✅ Utworzono core/infrastructure.py")
print("🔧 Zawiera kompletną infrastrukturę Redis, RabbitMQ, PostgreSQL, Circuit Breaker")