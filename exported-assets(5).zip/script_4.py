# 3. Infrastruktura systemu - poprawiona wersja
infrastructure_code_fixed = '''# core/infrastructure.py
"""
Projekt Feniks - Infrastruktura systemu
Redis, RabbitMQ, PostgreSQL, Circuit Breaker
"""

import json
import time
import asyncio
import aioredis
import psycopg2
from typing import Dict, Any, Optional, List
from contextlib import asynccontextmanager
from dataclasses import dataclass, asdict
from enum import Enum
import pika
from pika.adapters.asyncio_connection import AsyncioConnection
from pycircuitbreaker import CircuitBreaker, CircuitBreakerRegistry

class TaskStatus(Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"

@dataclass
class Task:
    """Podstawowa struktura zadania"""
    id: str
    type: str
    payload: Dict[str, Any]
    status: TaskStatus = TaskStatus.PENDING
    priority: int = 5
    max_retries: int = 3
    current_retry: int = 0
    created_at: float = None
    scheduled_for: float = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = time.time()
        if self.scheduled_for is None:
            self.scheduled_for = time.time()

class RedisManager:
    """Zarządzanie połączeniem Redis z poolem połączeń"""
    
    def __init__(self, config):
        self.config = config
        self.pool = None
        self.logger = None
    
    async def initialize(self):
        """Inicjalizacja puli połączeń Redis"""
        from core.logging import StructuredLogger
        self.logger = StructuredLogger("redis_manager")
        
        try:
            self.pool = aioredis.ConnectionPool.from_url(
                f"redis://{self.config.host}:{self.config.port}/{self.config.db}",
                password=self.config.password if self.config.password else None,
                max_connections=self.config.max_connections
            )
            
            # Test połączenia
            async with aioredis.Redis(connection_pool=self.pool) as redis:
                await redis.ping()
            
            self.logger.info("Redis connection pool initialized successfully")
            
        except Exception as e:
            self.logger.error("Failed to initialize Redis connection pool", exception=e)
            raise
    
    @asynccontextmanager
    async def get_connection(self):
        """Context manager dla połączenia Redis"""
        redis = aioredis.Redis(connection_pool=self.pool)
        try:
            yield redis
        finally:
            await redis.close()
    
    async def set_with_expiry(self, key: str, value: Any, expire_seconds: int = 3600):
        """Ustawienie wartości z wygaśnięciem"""
        async with self.get_connection() as redis:
            if isinstance(value, dict):
                value = json.dumps(value)
            await redis.setex(key, expire_seconds, value)
    
    async def get_json(self, key: str) -> Optional[Dict]:
        """Pobranie wartości jako JSON"""
        async with self.get_connection() as redis:
            value = await redis.get(key)
            if value:
                return json.loads(value.decode())
            return None

class RabbitMQManager:
    """Zarządzanie kolejkami RabbitMQ"""
    
    def __init__(self, config):
        self.config = config
        self.connection = None
        self.channel = None
        self.logger = None
        self.queues = {
            'proxy_validation': 'proxy_validation_queue',
            'sms_validation': 'sms_validation_queue',
            'registration_attempt': 'registration_attempt_queue',
            'analysis': 'analysis_queue',
            'strategy_adjustment': 'strategy_adjustment_queue'
        }
    
    async def initialize(self):
        """Inicjalizacja połączenia RabbitMQ"""
        from core.logging import StructuredLogger
        self.logger = StructuredLogger("rabbitmq_manager")
        
        try:
            connection_params = pika.ConnectionParameters(
                host=self.config.host,
                port=self.config.port,
                virtual_host=self.config.virtual_host,
                credentials=pika.PlainCredentials(
                    self.config.username,
                    self.config.password
                )
            )
            
            self.connection = pika.BlockingConnection(connection_params)
            self.channel = self.connection.channel()
            
            # Deklaracja kolejek
            for queue_name in self.queues.values():
                self.channel.queue_declare(
                    queue=queue_name,
                    durable=True,
                    arguments={'x-max-priority': 10}
                )
            
            self.logger.info("RabbitMQ connection and queues initialized successfully")
            
        except Exception as e:
            self.logger.error("Failed to initialize RabbitMQ", exception=e)
            raise

class EnhancedCircuitBreaker:
    """Zaawansowany Circuit Breaker z metrykami"""
    
    def __init__(self, name: str, failure_threshold: int = 5, timeout: int = 30):
        self.name = name
        self.circuit_breaker = CircuitBreaker(
            failure_threshold=failure_threshold,
            recovery_timeout=timeout,
            expected_exception=Exception
        )
        self.logger = None
        self.registry = CircuitBreakerRegistry()
        self.registry.add(self.circuit_breaker)
    
    def __call__(self, func):
        """Dekorator dla funkcji"""
        from core.logging import StructuredLogger
        if not self.logger:
            self.logger = StructuredLogger(f"circuit_breaker_{self.name}")
        
        def wrapper(*args, **kwargs):
            try:
                with self.circuit_breaker:
                    return func(*args, **kwargs)
            except Exception as e:
                self.logger.error(
                    f"Circuit breaker {self.name} - function failed",
                    function=func.__name__,
                    state=self.circuit_breaker.current_state,
                    exception=e
                )
                raise
        
        return wrapper

class InfrastructureManager:
    """Główny menedżer infrastruktury"""
    
    def __init__(self, config):
        self.config = config
        self.redis = RedisManager(config.redis)
        self.rabbitmq = RabbitMQManager(config.rabbitmq)
        self.circuit_breakers = {}
        self.logger = None
    
    async def initialize(self):
        """Inicjalizacja całej infrastruktury"""
        from core.logging import StructuredLogger, init_monitoring
        self.logger = StructuredLogger("infrastructure_manager")
        
        try:
            # Inicjalizacja monitoringu
            init_monitoring(self.config.prometheus.port)
            
            # Inicjalizacja komponentów
            await self.redis.initialize()
            await self.rabbitmq.initialize()
            
            # Utworzenie circuit breakers
            self._create_circuit_breakers()
            
            self.logger.info("Infrastructure initialized successfully")
            
        except Exception as e:
            self.logger.error("Failed to initialize infrastructure", exception=e)
            raise
    
    def _create_circuit_breakers(self):
        """Utworzenie circuit breakers dla kluczowych serwisów"""
        services = ['proxy_validation', 'sms_service', 'registration', 'analysis']
        
        for service in services:
            self.circuit_breakers[service] = EnhancedCircuitBreaker(
                name=service,
                failure_threshold=self.config.circuit_breaker_threshold,
                timeout=self.config.circuit_breaker_timeout
            )
'''

# Zapisz infrastrukturę
with open('infrastructure_system.py', 'w', encoding='utf-8') as f:
    f.write(infrastructure_code_fixed)

print("✅ Utworzono core/infrastructure.py")
print("🔧 Zawiera kompletną infrastrukturę Redis, RabbitMQ, Circuit Breaker")