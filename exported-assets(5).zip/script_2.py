# 2. Struktura logowania i monitoringu
logging_code = '''# core/logging.py
"""
Projekt Feniks - Zaawansowany system logowania
Strukturalne logowanie zgodne z najlepszymi praktykami enterprise
"""

import sys
import json
import time
import logging
import structlog
import traceback
from datetime import datetime
from typing import Dict, Any, Optional
from prometheus_client import Counter, Histogram, Gauge, start_http_server

# Metryki Prometheus
OPERATION_COUNTER = Counter('feniks_operations_total', 'Total operations', ['module', 'operation', 'status'])
OPERATION_DURATION = Histogram('feniks_operation_duration_seconds', 'Operation duration', ['module', 'operation'])
ACTIVE_AGENTS = Gauge('feniks_active_agents', 'Currently active agents', ['agent_type'])

class PrometheusMetrics:
    """Centralna klasa do zarządzania metrykami Prometheus"""
    
    @staticmethod
    def increment_operation(module: str, operation: str, status: str = 'success'):
        OPERATION_COUNTER.labels(module=module, operation=operation, status=status).inc()
    
    @staticmethod
    def observe_duration(module: str, operation: str, duration: float):
        OPERATION_DURATION.labels(module=module, operation=operation).observe(duration)
    
    @staticmethod
    def set_active_agents(agent_type: str, count: int):
        ACTIVE_AGENTS.labels(agent_type=agent_type).set(count)

class StructuredLogger:
    """Zaawansowany system logowania dla Projektu Feniks"""
    
    def __init__(self, component_name: str):
        self.component_name = component_name
        self.logger = self._setup_logger()
    
    def _setup_logger(self) -> structlog.BoundLogger:
        """Konfiguracja structured logger"""
        
        # Konfiguracja processsorów
        processors = [
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            self._add_component_context,
            structlog.dev.ConsoleRenderer() if sys.stdout.isatty() else structlog.processors.JSONRenderer()
        ]
        
        structlog.configure(
            processors=processors,
            logger_factory=structlog.stdlib.LoggerFactory(),
            cache_logger_on_first_use=True,
        )
        
        return structlog.get_logger(component=self.component_name)
    
    def _add_component_context(self, logger, method_name, event_dict):
        """Dodaje kontekst komponentu do każdego logu"""
        event_dict['component'] = self.component_name
        event_dict['timestamp'] = datetime.utcnow().isoformat()
        return event_dict
    
    def info(self, message: str, **kwargs):
        """Log informacyjny"""
        self.logger.info(message, **kwargs)
    
    def error(self, message: str, exception: Optional[Exception] = None, **kwargs):
        """Log błędu z opcjonalnym stack trace"""
        if exception:
            kwargs['exception_type'] = type(exception).__name__
            kwargs['exception_message'] = str(exception)
            kwargs['stack_trace'] = traceback.format_exc()
        self.logger.error(message, **kwargs)
    
    def warning(self, message: str, **kwargs):
        """Log ostrzeżenia"""
        self.logger.warning(message, **kwargs)
    
    def debug(self, message: str, **kwargs):
        """Log debugowania"""
        self.logger.debug(message, **kwargs)
    
    def audit(self, operation: str, user_id: str = None, resource: str = None, **kwargs):
        """Specjalny log audytowy"""
        audit_data = {
            'audit': True,
            'operation': operation,
            'user_id': user_id,
            'resource': resource,
            **kwargs
        }
        self.logger.info("AUDIT", **audit_data)

class PerformanceMonitor:
    """Monitoring wydajności operacji"""
    
    def __init__(self, logger: StructuredLogger, module: str, operation: str):
        self.logger = logger
        self.module = module
        self.operation = operation
        self.start_time = None
    
    def __enter__(self):
        self.start_time = time.time()
        self.logger.debug(f"Starting {self.operation}", operation=self.operation)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        duration = time.time() - self.start_time
        status = 'error' if exc_type else 'success'
        
        # Metryki Prometheus
        PrometheusMetrics.increment_operation(self.module, self.operation, status)
        PrometheusMetrics.observe_duration(self.module, self.operation, duration)
        
        # Logowanie
        self.logger.info(
            f"Completed {self.operation}",
            operation=self.operation,
            duration_seconds=duration,
            status=status
        )
        
        if exc_type:
            self.logger.error(
                f"Failed {self.operation}",
                operation=self.operation,
                exception=exc_val
            )

class HealthChecker:
    """System sprawdzania stanu zdrowia komponentów"""
    
    def __init__(self):
        self.health_status = {}
        self.logger = StructuredLogger("health_checker")
    
    def register_component(self, component_name: str):
        """Rejestracja komponentu do monitoringu"""
        self.health_status[component_name] = {
            'status': 'unknown',
            'last_check': None,
            'error_count': 0
        }
    
    def update_health(self, component_name: str, is_healthy: bool, error_message: str = None):
        """Aktualizacja stanu zdrowia komponentu"""
        if component_name not in self.health_status:
            self.register_component(component_name)
        
        status = 'healthy' if is_healthy else 'unhealthy'
        self.health_status[component_name].update({
            'status': status,
            'last_check': datetime.utcnow().isoformat(),
            'error_message': error_message
        })
        
        if not is_healthy:
            self.health_status[component_name]['error_count'] += 1
            self.logger.error(
                f"Component unhealthy: {component_name}",
                component=component_name,
                error_message=error_message
            )
    
    def get_overall_health(self) -> Dict[str, Any]:
        """Zwraca ogólny stan zdrowia systemu"""
        healthy_components = sum(1 for h in self.health_status.values() if h['status'] == 'healthy')
        total_components = len(self.health_status)
        
        return {
            'overall_status': 'healthy' if healthy_components == total_components else 'degraded',
            'healthy_components': healthy_components,
            'total_components': total_components,
            'components': self.health_status
        }

# Globalne instancje
health_checker = HealthChecker()

def init_monitoring(prometheus_port: int = 8000):
    """Inicjalizacja systemu monitoringu"""
    try:
        start_http_server(prometheus_port)
        logger = StructuredLogger("monitoring")
        logger.info(f"Prometheus metrics server started on port {prometheus_port}")
    except Exception as e:
        logger = StructuredLogger("monitoring")
        logger.error("Failed to start Prometheus metrics server", exception=e)
'''

# Zapisz system logowania
with open('logging_system.py', 'w', encoding='utf-8') as f:
    f.write(logging_code)

print("✅ Utworzono core/logging.py")
print("📊 Zawiera zaawansowany system logowania i monitoringu")