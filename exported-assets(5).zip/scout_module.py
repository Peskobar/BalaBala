# modules/scout.py
"""
Projekt Feniks - Moduł Scout
Autonomiczne zbieranie i walidacja proxy oraz serwisów SMS
"""

import asyncio
import aiohttp
import time
import random
import re
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed

@dataclass
class ProxyResource:
    """Struktura zasobu proxy"""
    url: str
    provider: str
    country: str = None
    protocol: str = 'http'
    anonymity_level: str = 'unknown'
    speed_score: float = 0.0
    success_rate: float = 0.0
    last_validated: float = None
    status: str = 'unvalidated'

@dataclass
class SMSResource:
    """Struktura zasobu serwisu SMS"""
    service_url: str
    provider: str
    supports_google: bool = False
    average_delay: float = 0.0
    success_rate: float = 0.0
    last_validated: float = None
    status: str = 'unvalidated'

class ProxyHarvester:
    """Agent do zbierania proxy z różnych źródeł"""

    def __init__(self, infrastructure_manager):
        self.infrastructure = infrastructure_manager
        self.logger = None
        self.session = None

        # Źródła proxy
        self.proxy_sources = [
            'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all',
            'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
            'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt',
            'https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.txt'
        ]

        # Dorki do wyszukiwania proxy
        self.google_dorks = [
            'intext:"proxy list" filetype:txt',
            'inurl:proxy-list site:github.com',
            'intitle:"proxy server" intext:"port"',
            '"http proxy" filetype:json'
        ]

    async def initialize(self):
        """Inicjalizacja harvestera"""
        from core.logging import StructuredLogger
        self.logger = StructuredLogger("proxy_harvester")

        # Sesja HTTP z timeout i retry
        timeout = aiohttp.ClientTimeout(total=30)
        connector = aiohttp.TCPConnector(limit=100, limit_per_host=10)
        self.session = aiohttp.ClientSession(timeout=timeout, connector=connector)

        self.logger.info("Proxy harvester initialized")

    async def harvest_from_api_sources(self) -> List[ProxyResource]:
        """Zbieranie proxy z publicznych API"""
        proxies = []

        for source_url in self.proxy_sources:
            try:
                async with self.session.get(source_url) as response:
                    if response.status == 200:
                        content = await response.text()
                        source_proxies = self._parse_proxy_list(content, source_url)
                        proxies.extend(source_proxies)

                        self.logger.info(
                            f"Harvested {len(source_proxies)} proxies from API source",
                            source=source_url,
                            count=len(source_proxies)
                        )

                # Opóźnienie między żądaniami
                await asyncio.sleep(random.uniform(1, 3))

            except Exception as e:
                self.logger.error(f"Failed to harvest from {source_url}", exception=e)

        return proxies

    async def harvest_from_search_engines(self) -> List[ProxyResource]:
        """Zbieranie proxy przez wyszukiwanie Google dorkami"""
        proxies = []

        for dork in self.google_dorks:
            try:
                # Symulacja wyszukiwania Google
                search_results = await self._search_google_dork(dork)

                for result_url in search_results:
                    try:
                        async with self.session.get(result_url) as response:
                            if response.status == 200:
                                content = await response.text()
                                dork_proxies = self._parse_proxy_list(content, result_url)
                                proxies.extend(dork_proxies)
                    except Exception as e:
                        self.logger.debug(f"Failed to process search result {result_url}", exception=e)

                # Długie opóźnienie między dorkami aby uniknąć blokady
                await asyncio.sleep(random.uniform(30, 60))

            except Exception as e:
                self.logger.error(f"Failed to search with dork: {dork}", exception=e)

        return proxies

    def _parse_proxy_list(self, content: str, source: str) -> List[ProxyResource]:
        """Parsowanie listy proxy z różnych formatów"""
        proxies = []

        # Regex dla proxy w formacie IP:PORT
        proxy_pattern = r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{1,5})'
        matches = re.findall(proxy_pattern, content)

        for ip, port in matches:
            if self._is_valid_ip(ip) and self._is_valid_port(port):
                proxy_url = f"{ip}:{port}"
                proxy = ProxyResource(
                    url=proxy_url,
                    provider=self._extract_provider_from_url(source)
                )
                proxies.append(proxy)

        # Deduplikacja
        unique_proxies = {proxy.url: proxy for proxy in proxies}
        return list(unique_proxies.values())

    def _is_valid_ip(self, ip: str) -> bool:
        """Walidacja adresu IP"""
        parts = ip.split('.')
        if len(parts) != 4:
            return False

        try:
            for part in parts:
                num = int(part)
                if not 0 <= num <= 255:
                    return False
            return True
        except ValueError:
            return False

    def _is_valid_port(self, port: str) -> bool:
        """Walidacja portu"""
        try:
            port_num = int(port)
            return 1 <= port_num <= 65535
        except ValueError:
            return False

    def _extract_provider_from_url(self, url: str) -> str:
        """Ekstrakcja nazwy providera z URL"""
        try:
            domain = urlparse(url).netloc
            return domain.replace('www.', '')
        except:
            return 'unknown'

    async def _search_google_dork(self, dork: str) -> List[str]:
        """Symulacja wyszukiwania Google dorkiem"""
        # W rzeczywistej implementacji użylibyśmy prawdziwego API wyszukiwania
        # lub narzędzi takich jak serpapi

        self.logger.debug(f"Simulating Google dork search: {dork}")

        # Symulowane wyniki
        simulated_results = [
            'https://raw.githubusercontent.com/example/proxy-list/master/proxies.txt',
            'https://gist.githubusercontent.com/user/hash/raw/proxy_list.txt'
        ]

        return simulated_results

    async def run_harvest_cycle(self):
        """Jeden pełny cykl zbierania proxy"""
        try:
            self.logger.info("Starting proxy harvest cycle")

            # Zbieranie z różnych źródeł równolegle
            api_task = asyncio.create_task(self.harvest_from_api_sources())
            search_task = asyncio.create_task(self.harvest_from_search_engines())

            api_proxies, search_proxies = await asyncio.gather(api_task, search_task)

            # Połączenie i deduplikacja
            all_proxies = api_proxies + search_proxies
            unique_proxies = {proxy.url: proxy for proxy in all_proxies}
            final_proxies = list(unique_proxies.values())

            # Publikowanie do kolejki walidacji
            for proxy in final_proxies:
                task = self.infrastructure.create_validation_task('proxy', proxy.__dict__)
                await self.infrastructure.rabbitmq.publish_task('proxy_validation', task)

            self.logger.info(
                f"Harvest cycle completed",
                total_proxies=len(final_proxies),
                api_count=len(api_proxies),
                search_count=len(search_proxies)
            )

        except Exception as e:
            self.logger.error("Harvest cycle failed", exception=e)

class ProxyValidator:
    """Agent do walidacji proxy"""

    def __init__(self, infrastructure_manager):
        self.infrastructure = infrastructure_manager
        self.logger = None

        # Test endpoints
        self.test_endpoints = [
            'http://httpbin.org/ip',
            'http://icanhazip.com',
            'https://httpbin.org/user-agent',
            'https://google.com'
        ]

    async def initialize(self):
        """Inicjalizacja validatora"""
        from core.logging import StructuredLogger
        self.logger = StructuredLogger("proxy_validator")
        self.logger.info("Proxy validator initialized")

    async def validate_proxy(self, proxy: ProxyResource) -> Dict[str, Any]:
        """Walidacja pojedynczego proxy"""
        validation_result = {
            'proxy_url': proxy.url,
            'is_valid': False,
            'speed_score': 0.0,
            'anonymity_level': 'transparent',
            'supports_https': False,
            'error_message': None
        }

        try:
            # Test podstawowy - sprawdzenie czy proxy odpowiada
            start_time = time.time()

            async with aiohttp.ClientSession() as session:
                proxy_url = f"http://{proxy.url}"

                async with session.get(
                    self.test_endpoints[0],
                    proxy=proxy_url,
                    timeout=aiohttp.ClientTimeout(total=15)
                ) as response:

                    if response.status == 200:
                        response_time = time.time() - start_time
                        response_data = await response.text()

                        validation_result.update({
                            'is_valid': True,
                            'speed_score': max(0, 10 - response_time),  # Score 0-10
                            'response_time': response_time
                        })

                        # Test anonimowości
                        anonymity = await self._test_anonymity(session, proxy_url)
                        validation_result['anonymity_level'] = anonymity

                        # Test HTTPS
                        https_support = await self._test_https_support(session, proxy_url)
                        validation_result['supports_https'] = https_support

                        self.logger.info(
                            f"Proxy validation successful",
                            proxy=proxy.url,
                            speed_score=validation_result['speed_score'],
                            anonymity=anonymity
                        )
                    else:
                        validation_result['error_message'] = f"HTTP {response.status}"

        except asyncio.TimeoutError:
            validation_result['error_message'] = 'Timeout'
        except Exception as e:
            validation_result['error_message'] = str(e)
            self.logger.debug(f"Proxy validation failed", proxy=proxy.url, exception=e)

        return validation_result

    async def _test_anonymity(self, session: aiohttp.ClientSession, proxy_url: str) -> str:
        """Test poziomu anonimowości proxy"""
        try:
            # Pobierz IP bez proxy
            async with session.get('http://httpbin.org/ip') as response:
                real_ip_data = await response.json()
                real_ip = real_ip_data.get('origin', '')

            # Pobierz IP przez proxy
            async with session.get('http://httpbin.org/ip', proxy=proxy_url) as response:
                proxy_ip_data = await response.json()
                proxy_ip = proxy_ip_data.get('origin', '')

            # Sprawdź nagłówki
            async with session.get('http://httpbin.org/headers', proxy=proxy_url) as response:
                headers_data = await response.json()
                headers = headers_data.get('headers', {})

            # Analiza anonimowości
            if real_ip in proxy_ip:
                return 'transparent'
            elif any(header.lower().startswith('x-') for header in headers.keys()):
                return 'anonymous'
            else:
                return 'elite'

        except Exception:
            return 'unknown'

    async def _test_https_support(self, session: aiohttp.ClientSession, proxy_url: str) -> bool:
        """Test wsparcia HTTPS"""
        try:
            async with session.get(
                'https://httpbin.org/ip',
                proxy=proxy_url,
                timeout=aiohttp.ClientTimeout(total=10)
            ) as response:
                return response.status == 200
        except Exception:
            return False

class SMSHarvester:
    """Agent do zbierania serwisów SMS"""

    def __init__(self, infrastructure_manager):
        self.infrastructure = infrastructure_manager
        self.logger = None

        # Znane serwisy SMS
        self.known_services = [
            'https://receive-sms.com/',
            'https://www.receivesmsonline.net/',
            'https://sms-online.co/receive-free-sms',
            'https://receivesms.co/',
            'https://7sim.net/'
        ]

        # Dorki do wyszukiwania nowych serwisów
        self.sms_dorks = [
            'intext:"receive sms online" intext:"free"',
            'intitle:"temporary phone number" intext:"verification"',
            '"receive sms" "google verification" site:*.com',
            'intext:"virtual phone number" intext:"free"'
        ]

    async def initialize(self):
        """Inicjalizacja SMS harvestera"""
        from core.logging import StructuredLogger
        self.logger = StructuredLogger("sms_harvester")
        self.logger.info("SMS harvester initialized")

    async def harvest_known_services(self) -> List[SMSResource]:
        """Zbieranie znanych serwisów SMS"""
        services = []

        for service_url in self.known_services:
            try:
                # Analiza struktury serwisu
                service_info = await self._analyze_sms_service(service_url)
                if service_info:
                    sms_resource = SMSResource(
                        service_url=service_url,
                        provider=self._extract_provider_from_url(service_url),
                        supports_google=service_info.get('supports_google', False)
                    )
                    services.append(sms_resource)

                    self.logger.info(f"Analyzed SMS service", service=service_url)

                await asyncio.sleep(random.uniform(2, 5))

            except Exception as e:
                self.logger.error(f"Failed to analyze SMS service {service_url}", exception=e)

        return services

    async def _analyze_sms_service(self, service_url: str) -> Optional[Dict[str, Any]]:
        """Analiza struktury serwisu SMS"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(service_url, timeout=aiohttp.ClientTimeout(total=15)) as response:
                    if response.status == 200:
                        content = await response.text()
                        soup = BeautifulSoup(content, 'html.parser')

                        # Szukaj wzorców wskazujących na wsparcie Google
                        google_patterns = ['google', 'gmail', 'verification', 'G-']
                        content_lower = content.lower()

                        supports_google = any(pattern in content_lower for pattern in google_patterns)

                        # Szukaj numerów telefonów na stronie
                        phone_pattern = r'\+?\d{1,3}[-.\s]?\d{3,4}[-.\s]?\d{3,4}[-.\s]?\d{3,4}'
                        phone_numbers = re.findall(phone_pattern, content)

                        return {
                            'supports_google': supports_google,
                            'available_numbers': len(phone_numbers),
                            'has_api': 'api' in content_lower
                        }
        except Exception as e:
            self.logger.debug(f"Error analyzing SMS service {service_url}", exception=e)
            return None

    def _extract_provider_from_url(self, url: str) -> str:
        """Ekstrakcja nazwy providera z URL"""
        try:
            domain = urlparse(url).netloc
            return domain.replace('www.', '')
        except:
            return 'unknown'

class ScoutOrchestrator:
    """Główny orkiestrator modułu Scout"""

    def __init__(self, infrastructure_manager):
        self.infrastructure = infrastructure_manager
        self.logger = None

        # Komponenty
        self.proxy_harvester = ProxyHarvester(infrastructure_manager)
        self.proxy_validator = ProxyValidator(infrastructure_manager)
        self.sms_harvester = SMSHarvester(infrastructure_manager)

        # Konfiguracja cykli
        self.harvest_interval = 3600  # 1 godzina
        self.validation_workers = 10

    async def initialize(self):
        """Inicjalizacja orkiestratora"""
        from core.logging import StructuredLogger, PerformanceMonitor
        self.logger = StructuredLogger("scout_orchestrator")

        # Inicjalizacja komponentów
        await self.proxy_harvester.initialize()
        await self.proxy_validator.initialize()
        await self.sms_harvester.initialize()

        self.logger.info("Scout orchestrator initialized successfully")

    async def run_harvest_cycle(self):
        """Uruchomienie pełnego cyklu zbierania zasobów"""
        from core.logging import PerformanceMonitor

        async with PerformanceMonitor(self.logger, "scout", "harvest_cycle"):
            try:
                # Równoległe zbieranie proxy i SMS
                proxy_task = asyncio.create_task(self.proxy_harvester.run_harvest_cycle())
                sms_task = asyncio.create_task(self._run_sms_harvest())

                await asyncio.gather(proxy_task, sms_task)

                self.logger.info("Scout harvest cycle completed successfully")

            except Exception as e:
                self.logger.error("Scout harvest cycle failed", exception=e)

    async def _run_sms_harvest(self):
        """Uruchomienie zbierania serwisów SMS"""
        try:
            services = await self.sms_harvester.harvest_known_services()

            # Publikowanie do kolejki walidacji
            for service in services:
                task = self.infrastructure.create_validation_task('sms', service.__dict__)
                await self.infrastructure.rabbitmq.publish_task('sms_validation', task)

            self.logger.info(f"SMS harvest completed", service_count=len(services))

        except Exception as e:
            self.logger.error("SMS harvest failed", exception=e)

    async def start_continuous_operation(self):
        """Uruchomienie ciągłej operacji modułu Scout"""
        self.logger.info("Starting Scout continuous operation")

        while True:
            try:
                await self.run_harvest_cycle()
                await asyncio.sleep(self.harvest_interval)

            except KeyboardInterrupt:
                self.logger.info("Scout operation interrupted by user")
                break
            except Exception as e:
                self.logger.error("Error in Scout continuous operation", exception=e)
                await asyncio.sleep(60)  # Krótkie opóźnienie przed ponowną próbą
