// Projekt Feniks Dashboard - Main Application Logic

class FeniksApp {
    constructor() {
        this.data = {
            agents: [
                {
                    id: "scout-001",
                    type: "Scout",
                    status: "active",
                    performance: 92,
                    tasksCompleted: 1247,
                    lastActive: "2025-06-29T14:30:15Z",
                    resources: { cpu: 23, memory: 67, network: 45 }
                },
                {
                    id: "operator-001", 
                    type: "Operator",
                    status: "active",
                    performance: 88,
                    tasksCompleted: 892,
                    lastActive: "2025-06-29T14:29:32Z",
                    resources: { cpu: 45, memory: 78, network: 67 }
                },
                {
                    id: "analyst-001",
                    type: "Analyst", 
                    status: "idle",
                    performance: 95,
                    tasksCompleted: 567,
                    lastActive: "2025-06-29T14:25:18Z",
                    resources: { cpu: 12, memory: 34, network: 23 }
                }
            ],
            metrics: {
                totalAgents: 3,
                activeAgents: 2,
                totalTasks: 2706,
                successRate: 94.2,
                avgResponseTime: "245ms",
                systemUptime: "99.8%"
            },
            tasks: [
                {
                    id: "task-001",
                    type: "Resource Discovery",
                    status: "running",
                    priority: "high",
                    assignedAgent: "scout-001",
                    progress: 67,
                    estimatedTime: "5 min"
                },
                {
                    id: "task-002",
                    type: "Data Analysis",
                    status: "pending",
                    priority: "medium", 
                    assignedAgent: "analyst-001",
                    progress: 0,
                    estimatedTime: "12 min"
                }
            ]
        };

        this.charts = {};
        this.updateInterval = null;
        this.notifications = [
            { id: 1, type: 'info', message: 'System uruchomiony pomyślnie', timestamp: new Date() },
            { id: 2, type: 'warning', message: 'Wysokie użycie pamięci przez Operator-001', timestamp: new Date() },
            { id: 3, type: 'success', message: 'Zadanie task-001 zakończone sukcesem', timestamp: new Date() }
        ];

        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeCharts();
        this.updateMetrics();
        this.renderAgents();
        this.renderTasks();
        this.generateLogs();
        this.startRealTimeUpdates();
        this.showLoadingOverlay();
        setTimeout(() => this.hideLoadingOverlay(), 1500);
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const section = item.dataset.section;
                this.navigateToSection(section);
            });
        });

        // Sidebar toggle
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        sidebarToggle?.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });

        // Notifications
        const notificationBtn = document.getElementById('notificationBtn');
        const notificationModal = document.getElementById('notificationModal');
        const modalClose = document.getElementById('modalClose');

        notificationBtn?.addEventListener('click', () => {
            this.showNotifications();
        });

        modalClose?.addEventListener('click', () => {
            notificationModal.classList.remove('active');
        });

        notificationModal?.addEventListener('click', (e) => {
            if (e.target === notificationModal) {
                notificationModal.classList.remove('active');
            }
        });
    }

    navigateToSection(section) {
        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-section="${section}"]`).classList.add('active');

        // Update content
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(`${section}-section`).classList.add('active');

        // Update page title
        const titles = {
            dashboard: 'Dashboard',
            agents: 'Zarządzanie agentami',
            monitoring: 'Monitoring systemu',
            tasks: 'Zarządzanie zadaniami',
            config: 'Konfiguracja',
            logs: 'Logi systemowe'
        };
        document.getElementById('pageTitle').textContent = titles[section] || 'Dashboard';
    }

    initializeCharts() {
        this.initPerformanceChart();
        this.initResourceChart();
        this.initAgentActivityChart();
    }

    initPerformanceChart() {
        const ctx = document.getElementById('performanceChart')?.getContext('2d');
        if (!ctx) return;

        const data = this.generatePerformanceData();
        
        this.charts.performance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [{
                    label: 'Wydajność systemu (%)',
                    data: data.values,
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: getComputedStyle(document.documentElement).getPropertyValue('--color-text')
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: getComputedStyle(document.documentElement).getPropertyValue('--color-text-secondary')
                        },
                        grid: {
                            color: 'rgba(94, 82, 64, 0.1)'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            color: getComputedStyle(document.documentElement).getPropertyValue('--color-text-secondary')
                        },
                        grid: {
                            color: 'rgba(94, 82, 64, 0.1)'
                        }
                    }
                }
            }
        });
    }

    initResourceChart() {
        const ctx = document.getElementById('resourceChart')?.getContext('2d');
        if (!ctx) return;

        const resourceData = this.calculateResourceUsage();
        
        this.charts.resource = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['CPU', 'Pamięć', 'Sieć', 'Dostępne'],
                datasets: [{
                    data: [resourceData.cpu, resourceData.memory, resourceData.network, resourceData.available],
                    backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: getComputedStyle(document.documentElement).getPropertyValue('--color-text'),
                            padding: 20
                        }
                    }
                }
            }
        });
    }

    initAgentActivityChart() {
        const ctx = document.getElementById('agentActivityChart')?.getContext('2d');
        if (!ctx) return;

        this.charts.agentActivity = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: this.data.agents.map(agent => agent.type),
                datasets: [{
                    label: 'Wykonane zadania',
                    data: this.data.agents.map(agent => agent.tasksCompleted),
                    backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C'],
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: getComputedStyle(document.documentElement).getPropertyValue('--color-text')
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: getComputedStyle(document.documentElement).getPropertyValue('--color-text-secondary')
                        },
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: getComputedStyle(document.documentElement).getPropertyValue('--color-text-secondary')
                        },
                        grid: {
                            color: 'rgba(94, 82, 64, 0.1)'
                        }
                    }
                }
            }
        });
    }

    generatePerformanceData() {
        const labels = [];
        const values = [];
        const now = new Date();
        
        for (let i = 29; i >= 0; i--) {
            const time = new Date(now.getTime() - i * 60000);
            labels.push(time.getHours().toString().padStart(2, '0') + ':' + 
                       time.getMinutes().toString().padStart(2, '0'));
            values.push(85 + Math.random() * 15);
        }
        
        return { labels, values };
    }

    calculateResourceUsage() {
        const totalCpu = this.data.agents.reduce((sum, agent) => sum + agent.resources.cpu, 0);
        const totalMemory = this.data.agents.reduce((sum, agent) => sum + agent.resources.memory, 0);
        const totalNetwork = this.data.agents.reduce((sum, agent) => sum + agent.resources.network, 0);
        const used = totalCpu + totalMemory + totalNetwork;
        const available = Math.max(300 - used, 0);

        return {
            cpu: totalCpu,
            memory: totalMemory,
            network: totalNetwork,
            available: available
        };
    }

    updateMetrics() {
        document.getElementById('totalAgents').textContent = this.data.metrics.totalAgents;
        document.getElementById('activeAgents').textContent = this.data.metrics.activeAgents;
        document.getElementById('totalTasks').textContent = this.data.metrics.totalTasks.toLocaleString('pl-PL');
        document.getElementById('successRate').textContent = this.data.metrics.successRate + '%';
        document.getElementById('systemUptime').textContent = this.data.metrics.systemUptime;
        document.getElementById('avgResponseTime').textContent = this.data.metrics.avgResponseTime;
        document.getElementById('lastUpdate').textContent = 'Przed chwilą';
    }

    renderAgents() {
        const agentsGrid = document.getElementById('agentsGrid');
        if (!agentsGrid) return;

        agentsGrid.innerHTML = this.data.agents.map(agent => `
            <div class="agent-card">
                <div class="agent-header">
                    <h3 class="agent-title">${agent.type} (${agent.id})</h3>
                    <span class="status status--${agent.status === 'active' ? 'success' : agent.status === 'idle' ? 'warning' : 'error'}">
                        ${agent.status === 'active' ? 'Aktywny' : agent.status === 'idle' ? 'Bezczynny' : 'Błąd'}
                    </span>
                </div>
                <div class="agent-metrics">
                    <div class="agent-metric">
                        <span class="agent-metric-label">Wydajność</span>
                        <span class="agent-metric-value">${agent.performance}%</span>
                    </div>
                    <div class="agent-metric">
                        <span class="agent-metric-label">Zadania</span>
                        <span class="agent-metric-value">${agent.tasksCompleted.toLocaleString('pl-PL')}</span>
                    </div>
                </div>
                <div class="agent-resources">
                    <h4>Wykorzystanie zasobów</h4>
                    <div class="resource-item">
                        <span>CPU</span>
                        <div class="resource-bar">
                            <div class="resource-progress" style="width: ${agent.resources.cpu}%"></div>
                        </div>
                        <span>${agent.resources.cpu}%</span>
                    </div>
                    <div class="resource-item">
                        <span>Pamięć</span>
                        <div class="resource-bar">
                            <div class="resource-progress" style="width: ${agent.resources.memory}%"></div>
                        </div>
                        <span>${agent.resources.memory}%</span>
                    </div>
                    <div class="resource-item">
                        <span>Sieć</span>
                        <div class="resource-bar">
                            <div class="resource-progress" style="width: ${agent.resources.network}%"></div>
                        </div>
                        <span>${agent.resources.network}%</span>
                    </div>
                </div>
                <div class="agent-actions">
                    <button class="btn btn--sm btn--primary" onclick="app.restartAgent('${agent.id}')">
                        <i class="fas fa-redo"></i> Restart
                    </button>
                    <button class="btn btn--sm btn--secondary" onclick="app.pauseAgent('${agent.id}')">
                        <i class="fas fa-pause"></i> Pauza
                    </button>
                    <button class="btn btn--sm btn--outline" onclick="app.viewAgentLogs('${agent.id}')">
                        <i class="fas fa-file-alt"></i> Logi
                    </button>
                </div>
            </div>
        `).join('');
    }

    renderTasks() {
        const tasksTableBody = document.getElementById('tasksTableBody');
        if (!tasksTableBody) return;

        tasksTableBody.innerHTML = this.data.tasks.map(task => `
            <tr>
                <td>${task.id}</td>
                <td>${task.type}</td>
                <td>
                    <span class="status status--${task.status === 'running' ? 'info' : task.status === 'pending' ? 'warning' : 'success'}">
                        ${task.status === 'running' ? 'Wykonywane' : task.status === 'pending' ? 'Oczekuje' : 'Zakończone'}
                    </span>
                </td>
                <td>
                    <span class="status status--${task.priority === 'high' ? 'error' : task.priority === 'medium' ? 'warning' : 'info'}">
                        ${task.priority === 'high' ? 'Wysoki' : task.priority === 'medium' ? 'Średni' : 'Niski'}
                    </span>
                </td>
                <td>${task.assignedAgent}</td>
                <td>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${task.progress}%"></div>
                    </div>
                    <span>${task.progress}%</span>
                </td>
                <td>${task.estimatedTime}</td>
                <td>
                    <div class="task-actions">
                        <button class="btn btn--sm btn--primary" onclick="app.viewTask('${task.id}')">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn--sm btn--secondary" onclick="app.editTask('${task.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn--sm btn--outline" onclick="app.deleteTask('${task.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    generateLogs() {
        const logsContainer = document.getElementById('logsContainer');
        if (!logsContainer) return;

        const logs = [
            { timestamp: '2025-06-29 14:30:15', level: 'info', message: 'Scout-001 rozpoczął zadanie resource discovery' },
            { timestamp: '2025-06-29 14:29:32', level: 'warning', message: 'Operator-001 przekroczył limit użycia pamięci (78%)' },
            { timestamp: '2025-06-29 14:28:45', level: 'info', message: 'Analyst-001 przeszedł w stan bezczynności' },
            { timestamp: '2025-06-29 14:27:12', level: 'error', message: 'Błąd połączenia z zewnętrznym API podczas zadania task-003' },
            { timestamp: '2025-06-29 14:26:30', level: 'info', message: 'System monitoring uruchomiony pomyślnie' },
            { timestamp: '2025-06-29 14:25:18', level: 'info', message: 'Zadanie task-004 zakończone sukcesem przez Analyst-001' },
            { timestamp: '2025-06-29 14:24:05', level: 'warning', message: 'Wysoka aktywność sieciowa wykryta w Scout-001' },
            { timestamp: '2025-06-29 14:23:42', level: 'info', message: 'Rozpoczęto automatyczne skalowanie zasobów' }
        ];

        logsContainer.innerHTML = logs.map(log => `
            <div class="log-entry">
                <span class="log-timestamp">${log.timestamp}</span>
                <span class="log-level ${log.level}">${log.level.toUpperCase()}</span>
                <span class="log-message">${log.message}</span>
            </div>
        `).join('');
    }

    showNotifications() {
        const modal = document.getElementById('notificationModal');
        const content = document.getElementById('notificationContent');
        
        content.innerHTML = this.notifications.map(notification => `
            <div class="notification-item" style="padding: 12px; border-bottom: 1px solid var(--color-border); display: flex; align-items: center; gap: 12px;">
                <i class="fas fa-${notification.type === 'info' ? 'info-circle text-info' : notification.type === 'warning' ? 'exclamation-triangle text-warning' : 'check-circle text-success'}"></i>
                <div style="flex: 1;">
                    <p style="margin: 0; font-size: 14px;">${notification.message}</p>
                    <small style="color: var(--color-text-secondary);">${this.formatTime(notification.timestamp)}</small>
                </div>
            </div>
        `).join('');
        
        modal.classList.add('active');
    }

    formatTime(date) {
        return new Intl.RelativeTimeFormat('pl', { numeric: 'auto' })
            .format(Math.floor((date - new Date()) / 60000), 'minute');
    }

    startRealTimeUpdates() {
        this.updateInterval = setInterval(() => {
            this.simulateRealTimeData();
            this.updateCharts();
        }, 5000);
    }

    simulateRealTimeData() {
        // Update agent resources
        this.data.agents.forEach(agent => {
            agent.resources.cpu = Math.max(0, Math.min(100, agent.resources.cpu + (Math.random() - 0.5) * 10));
            agent.resources.memory = Math.max(0, Math.min(100, agent.resources.memory + (Math.random() - 0.5) * 8));
            agent.resources.network = Math.max(0, Math.min(100, agent.resources.network + (Math.random() - 0.5) * 12));
        });

        // Update task progress
        this.data.tasks.forEach(task => {
            if (task.status === 'running' && task.progress < 100) {
                task.progress = Math.min(100, task.progress + Math.random() * 5);
                if (task.progress >= 100) {
                    task.status = 'completed';
                }
            }
        });

        // Update metrics
        this.data.metrics.successRate = 90 + Math.random() * 10;
        this.data.metrics.avgResponseTime = Math.floor(200 + Math.random() * 100) + 'ms';

        this.renderAgents();
        this.renderTasks();
        this.updateMetrics();
    }

    updateCharts() {
        if (this.charts.performance) {
            const newData = this.generatePerformanceData();
            this.charts.performance.data.labels = newData.labels;
            this.charts.performance.data.datasets[0].data = newData.values;
            this.charts.performance.update('none');
        }

        if (this.charts.resource) {
            const resourceData = this.calculateResourceUsage();
            this.charts.resource.data.datasets[0].data = [
                resourceData.cpu, resourceData.memory, resourceData.network, resourceData.available
            ];
            this.charts.resource.update('none');
        }
    }

    showLoadingOverlay() {
        document.getElementById('loadingOverlay').classList.add('active');
    }

    hideLoadingOverlay() {
        document.getElementById('loadingOverlay').classList.remove('active');
    }

    // Agent Actions
    restartAgent(agentId) {
        this.showLoadingOverlay();
        setTimeout(() => {
            const agent = this.data.agents.find(a => a.id === agentId);
            if (agent) {
                agent.status = 'active';
                agent.resources = { cpu: 15, memory: 25, network: 20 };
                this.renderAgents();
                this.addNotification('success', `Agent ${agentId} został zrestartowany pomyślnie`);
            }
            this.hideLoadingOverlay();
        }, 1000);
    }

    pauseAgent(agentId) {
        const agent = this.data.agents.find(a => a.id === agentId);
        if (agent) {
            agent.status = agent.status === 'active' ? 'idle' : 'active';
            this.renderAgents();
            this.addNotification('info', `Agent ${agentId} ${agent.status === 'idle' ? 'wstrzymany' : 'wznowiony'}`);
        }
    }

    viewAgentLogs(agentId) {
        this.navigateToSection('logs');
        this.addNotification('info', `Wyświetlono logi dla agenta ${agentId}`);
    }

    // Task Actions
    viewTask(taskId) {
        this.addNotification('info', `Wyświetlono szczegóły zadania ${taskId}`);
    }

    editTask(taskId) {
        this.addNotification('info', `Edycja zadania ${taskId}`);
    }

    deleteTask(taskId) {
        if (confirm('Czy na pewno chcesz usunąć to zadanie?')) {
            this.data.tasks = this.data.tasks.filter(task => task.id !== taskId);
            this.renderTasks();
            this.addNotification('warning', `Zadanie ${taskId} zostało usunięte`);
        }
    }

    addNotification(type, message) {
        const notification = {
            id: Date.now(),
            type: type,
            message: message,
            timestamp: new Date()
        };
        this.notifications.unshift(notification);
        
        // Keep only last 10 notifications
        this.notifications = this.notifications.slice(0, 10);
        
        // Update badge
        document.getElementById('notificationBadge').textContent = this.notifications.length;
    }

    destroy() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
        }
        Object.values(this.charts).forEach(chart => {
            if (chart) chart.destroy();
        });
    }
}

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new FeniksApp();
});

// Handle page unload
window.addEventListener('beforeunload', () => {
    if (window.app) {
        window.app.destroy();
    }
});