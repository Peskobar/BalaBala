# Poprawiona analiza błędów z poprzedniej konwersacji i utworzenie wstępnego planu

analysis = {
    "previous_errors": [
        {
            "error": "Brak konkretnej implementacji backendu",
            "description": "Poprzednia konwersacja skupiała się głównie na froncie i teorii",
            "priority": "Krytyczny"
        },
        {
            "error": "Niejasne API endpoints",
            "description": "Nie zdefiniowano konkretnych endpointów REST/GraphQL", 
            "priority": "Wysoki"
        },
        {
            "error": "Brak integracji z bazami danych",
            "description": "Nie pokazano konkretnej implementacji z Redis/PostgreSQL/RabbitMQ",
            "priority": "Wysoki"
        },
        {
            "error": "Brak real-time WebSocket implementation",
            "description": "Teoretyczne omówienie bez kodu",
            "priority": "Średni"
        },
        {
            "error": "Brak testów i monitoringu",
            "description": "Nie uwzględniono testowania distributed systems",
            "priority": "Średni"
        }
    ],
    
    "architecture_plan": {
        "backend_stack": {
            "framework": "Play Framework 3.0.x with Scala",
            "streams": "Pekko Streams (Apache Pekko)",
            "database": "PostgreSQL 16+ (primary), Redis 7+ (cache), RabbitMQ 3.12+ (messaging)",
            "api": "Hybrid REST + GraphQL",
            "realtime": "WebSockets with Pekko Streams",
            "monitoring": "Prometheus + Grafana + custom metrics"
        },
        
        "modules": {
            "scout": "Resource discovery and validation agents",
            "operator": "Task execution and coordination agents", 
            "analyst": "Data analysis and ML agents",
            "gateway": "API Gateway with authentication",
            "dashboard": "Real-time metrics and monitoring"
        },
        
        "patterns": [
            "Event-Driven Architecture",
            "CQRS (Command Query Responsibility Segregation)",
            "Saga Pattern for distributed transactions",
            "Circuit Breaker for resilience",
            "Actor Model with Pekko"
        ]
    },
    
    "implementation_phases": [
        "Phase 1: Core infrastructure (databases, messaging)",
        "Phase 2: Agent framework and basic APIs", 
        "Phase 3: Real-time WebSockets and dashboard",
        "Phase 4: Advanced features (ML, analytics)",
        "Phase 5: Testing, monitoring and deployment"
    ]
}

print("=== ANALIZA BŁĘDÓW I PLAN ARCHITEKTURY ===")
print(f"\nZidentyfikowane błędy z poprzedniej iteracji: {len(analysis['previous_errors'])}")
for i, error in enumerate(analysis['previous_errors'], 1):
    print(f"{i}. {error['error']} ({error['priority']})")
    print(f"   {error['description']}")

print(f"\n=== PLAN ARCHITEKTURY BACKENDU ===")
print(f"Framework: {analysis['architecture_plan']['backend_stack']['framework']}")
print(f"Bazy danych: {analysis['architecture_plan']['backend_stack']['database']}")
print(f"API: {analysis['architecture_plan']['backend_stack']['api']}")

print(f"\n=== MODUŁY SYSTEMU ===")
for module, desc in analysis['architecture_plan']['modules'].items():
    print(f"- {module.upper()}: {desc}")

print(f"\n=== WZORCE ARCHITEKTONICZNE ===")
for pattern in analysis['architecture_plan']['patterns']:
    print(f"- {pattern}")

print(f"\n=== FAZY IMPLEMENTACJI ===")
for phase in analysis['implementation_phases']:
    print(f"- {phase}")

# Utworzenie struktury projektu
project_structure = {
    "fenix-backend/": {
        "app/": {
            "controllers/": ["AgentController.scala", "DashboardController.scala", "GraphQLController.scala"],
            "models/": ["Agent.scala", "Task.scala", "Metrics.scala"],
            "services/": ["AgentService.scala", "MessagingService.scala", "DatabaseService.scala"],
            "actors/": ["ScoutActor.scala", "OperatorActor.scala", "AnalystActor.scala"],
            "graphql/": ["Schema.scala", "Resolvers.scala"],
            "streams/": ["RealTimeStreams.scala", "EventProcessor.scala"]
        },
        "conf/": ["application.conf", "routes", "evolutions/"],
        "build.sbt": "Dependencies and build configuration",
        "project/": ["plugins.sbt", "build.properties"],
        "test/": ["Unit tests", "Integration tests", "Performance tests"]
    }
}

print(f"\n=== STRUKTURA PROJEKTU ===")
def print_structure(structure, indent=0):
    for name, content in structure.items():
        print("  " * indent + name)
        if isinstance(content, dict):
            print_structure(content, indent + 1)
        elif isinstance(content, list):
            for item in content:
                print("  " * (indent + 1) + item)
        else:
            print("  " * (indent + 1) + content)

print_structure(project_structure)